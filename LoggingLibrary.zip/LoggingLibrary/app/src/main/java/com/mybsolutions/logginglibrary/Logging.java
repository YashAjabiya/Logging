package com.mybsolutions.logginglibrary;

import android.util.Log;

/**
 * Created by Yash Ajabiya on 11/3/2017.
 */

public class Logging {

    public static void logDebug(String text) {
        try {
            Log.d("LogLibrary", text);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void logError(String text) {
        try {
            Log.e("LogLibrary", text);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void logInfo(String text) {
        try {
            Log.i("LogLibrary", text);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
